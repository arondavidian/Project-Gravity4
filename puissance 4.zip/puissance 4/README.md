# Gravity 4 (PC)

Jeu de puissance 4 en Python avec interface Pygame, musique, sauvegarde locale et plusieurs niveaux d?IA. Le projet est destin? ? Windows et aux ordinateurs de bureau.

## Installation

1. Installez Python 3.10 ou plus r?cent.
2. Ouvrez PowerShell dans le dossier du projet.
3. Installez Pygame :

   ```powershell
   python -m pip install -r requirements.txt
   ```

## Lancement

```powershell
python main.py
```

La sauvegarde `connect4_save.json` conserve les r?glages, tokens et la progression. Les anciennes donn?es de cosm?tiques restent dans le fichier pour pr?server la sauvegarde, mais le jeu ne les charge plus et ne les utilise plus.

La musique et les sons sont g?n?r?s par le jeu. Les images `red_token.png` et `blue_token.png` sont facultatives; des jetons sont dessin?s automatiquement si elles sont absentes.
