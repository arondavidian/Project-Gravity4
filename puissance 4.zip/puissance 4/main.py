"""Launcher for the Gravity 4 desktop game."""

from connect4_ai import play_game_pygame


if __name__ == "__main__":
    play_game_pygame()
